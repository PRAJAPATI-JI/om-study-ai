package com.omstudy.ai.ui

import android.app.Application
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.omstudy.ai.alarm.AlarmScheduler
import com.omstudy.ai.data.AlarmEntity
import com.omstudy.ai.data.AppDatabase
import com.omstudy.ai.data.Prefs
import com.omstudy.ai.data.TaskEntity
import com.omstudy.ai.data.dataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val db = AppDatabase.get(ctx)

    val alarms = db.alarmDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _day = MutableStateFlow(LocalDate.now().toEpochDay())
    val day: StateFlow<Long> = _day

    @OptIn(ExperimentalCoroutinesApi::class)
    val tasks = _day.flatMapLatest { db.taskDao().observeDay(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayTasks = db.taskDao().observeDay(LocalDate.now().toEpochDay())
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayLogs = db.logDao().observeSince(
        LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val themeMode = ctx.dataStore.data.map { it[Prefs.THEME] ?: 0 }
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    val userName = ctx.dataStore.data.map { it[Prefs.NAME] ?: "" }
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")

    // ---- अलार्म ----
    fun saveAlarm(alarm: AlarmEntity) = viewModelScope.launch(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val id = db.alarmDao().upsert(alarm.copy(updatedAt = now))
        AlarmScheduler.schedule(ctx, alarm.copy(id = if (alarm.id == 0L) id else alarm.id, updatedAt = now))
    }

    fun deleteAlarm(alarm: AlarmEntity) = viewModelScope.launch(Dispatchers.IO) {
        AlarmScheduler.cancel(ctx, alarm.id)
        db.alarmDao().delete(alarm)
    }

    fun toggleAlarm(alarm: AlarmEntity, enabled: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        db.alarmDao().setEnabled(alarm.id, enabled, System.currentTimeMillis())
        AlarmScheduler.schedule(ctx, alarm.copy(enabled = enabled))
    }

    // ---- प्लानर ----
    fun setDay(epochDay: Long) {
        _day.value = epochDay
    }

    fun saveTask(task: TaskEntity) = viewModelScope.launch(Dispatchers.IO) { db.taskDao().upsert(task) }

    fun deleteTask(task: TaskEntity) = viewModelScope.launch(Dispatchers.IO) { db.taskDao().delete(task) }

    fun toggleTask(task: TaskEntity, done: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        db.taskDao().upsert(task.copy(done = done, doneAt = if (done) System.currentTimeMillis() else null))
    }

    /** अधूरा काम अगले दिन के लिए टालना */
    fun postponeTask(task: TaskEntity) = viewModelScope.launch(Dispatchers.IO) {
        db.taskDao().upsert(task.copy(epochDay = task.epochDay + 1, done = false, doneAt = null))
    }

    // ---- सेटिंग्स ----
    fun setTheme(mode: Int) = viewModelScope.launch { ctx.dataStore.edit { it[Prefs.THEME] = mode } }

    fun setName(name: String) = viewModelScope.launch { ctx.dataStore.edit { it[Prefs.NAME] = name.trim().take(40) } }

    fun testAlarm() = AlarmScheduler.scheduleTest(ctx, 10)

    fun clearAll(onDone: () -> Unit) = viewModelScope.launch(Dispatchers.IO) {
        db.alarmDao().all().forEach { AlarmScheduler.cancel(ctx, it.id) }
        db.clearAllTables()
        ctx.dataStore.edit { it.clear() }
        withContext(Dispatchers.Main) { onDone() }
    }
}
