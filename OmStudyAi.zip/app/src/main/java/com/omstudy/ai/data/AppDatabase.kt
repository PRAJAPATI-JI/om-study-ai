package com.omstudy.ai.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * डेटाबेस version 1। आगे नए फीचर जुड़ें तो version बढ़ाकर Migration जोड़ा जाएगा,
 * ताकि ऐप अपडेट होने पर आपका डेटा न मिटे (fallbackToDestructiveMigration जानबूझकर नहीं लगाया)।
 */
@Database(
    entities = [AlarmEntity::class, TaskEntity::class, AlarmLogEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun alarmDao(): AlarmDao
    abstract fun taskDao(): TaskDao
    abstract fun logDao(): LogDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "om_study.db"
                ).build().also { instance = it }
            }
    }
}
